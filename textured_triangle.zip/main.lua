-- main for textured_triangle.love

function love.load()
	gr, li, pi				= love.graphics, love.image, math.pi
	gr.setCaption( 'Mask' )
	smallfont				= gr.newFont(18)
	gr.setFont(smallfont)
	image					= gr.newImage( 'test.jpg')
	bckgnd					= gr.newImage( 'MyTest1.jpg' )
	wd, ht					= gr.getWidth(),gr.getHeight()
	angle					= 0
	-- sure you really want to know?
	--		tc - location of triangle on texture
	--		tl - location of triangle on screen
	--		ts - triangle size
	tcx,tcy,tsx,tsy,tlx,tly	= 180,120,200,200,wd/2,ht/2
	canvas					= gr.newCanvas( wd, ht )
	load_effect()
	reset()
	info = {
			" Keyboard Controls",
			"triangle location:",
			"  X: <f><h>",
			"  Y: <t><g>",
			"texture",
			"  X: <a><d>",
			"  Y: <w><s>",
			"triangle size:",
			"  X: <left><right>",
			"  Y: <up><down>"
			}
	end

function love.draw()
	gr.setColorMode( 'replace' )
	gr.draw( bckgnd )
	gr.draw( tex_image, tlx, tly, angle, 1, 1, tcx, tcy )
	gr.setColorMode( 'modulate' )
	gr.print( 'FPS: '..love.timer.getFPS(), wd-100, 10 )
	key_options()
	show_data()
	end

function love.update( dt )
	angle		=  angle + dt
	if angle	>= 2*pi then angle = angle - 2*pi end
	end

function love.keypressed(key)
	if key == 'escape'	then love.event.push('quit') end
	if key == 'up'		then tsy=tsy+10 if tcy-tsy/2<0 then tsy = 2*tcy end reset()end
	if key == 'down'	then tsy=tsy-10 reset()end
	if key == 'left'	then tsx=tsx-10 if tsx< tcx-tsx/2 then tsx=tcx-tsx/2 end reset()end
	if key == 'right'	then tsx=tsx+10 if tcx-tsx/2<0 then tsx=2*tcx end reset()end
	if key == 'a'		then tcx=tcx-10 reset()end
	if key == 'd'		then tcx=tcx+10 reset() end
	if key == 'w'		then tcy=tcy-10 reset() end
	if key == 's'		then tcy=tcy+10 reset() end
	if key == 'f'		then tlx=tlx-20 end
	if key == 'h'		then tlx=tlx+20 end
	if key == 't'		then tly=tly-20 end
	if key == 'g'		then tly=tly+20 end
	end

function reset()
	load_mask()
	create_texture()
	end

function create_texture()
	gr.clear()
	gr.setPixelEffect( effect )
	gr.draw( image )
	gr.setPixelEffect()
	tex_image	= gr.newImage( gr.newScreenshot() )
	end

function mask_content()
	canvas:clear( 0,0,0,0 )		-- transparent background
	gr.setBackgroundColor(0,0,0,0)
	gr.setColor( 255, 255, 255, 255 )		-- white hole in mask
	poly = {tcx-tsx/2,tcy+tsy/2,tcx,tcy-tsy/2,tcx+tsx/2,tcy+tsy/2}
	gr.polygon( 'fill', poly ) -- the triangle
	end

function load_effect()
	effect = gr.newPixelEffect [[
	extern Image  mask;
	vec4 effect(vec4 color,Image tex,vec2 tc,vec2 pc)
	{
		vec4 img_color		= Texel( tex, tc );
		tc.y				= 1 - tc.y;	// invert 'y' axes
		vec4 mask_color		= Texel( mask, tc );
		img_color.a 		= mask_color.a;
		return img_color;
		}
	]]
	end

function load_mask()
	canvas:renderTo( mask_content )
	effect:send( 'mask', canvas )
	end

function key_options()
	gr.setColor( 255, 255, 0, 255 )
	for i = 1, #info do gr.print( info[i], 10, i * 20 ) end
	end

function show_data()
	gr.setColor( 255, 255, 0, 255 )
	data = {
		"Triangle Settings",
		"X location: "..tlx,
		"Y location: "..tly,
		"X size: "..tsx,
		"Y size: "..tsy,
		"image X: "..tcx,
		"image Y: "..tcy,
		"rotation angle: "..math.floor(angle*180/pi)
		}
	local x, y = 10, 20
	for i = 1, #data do
		gr.print( data[i], x, i * y+ 420 )
		end
	end


